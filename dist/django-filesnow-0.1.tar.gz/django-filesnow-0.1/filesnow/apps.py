from django.apps import AppConfig


class FilesnowConfig(AppConfig):
    name = 'filesnow'
